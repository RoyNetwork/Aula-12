__author__ ='Alan (Roy)'

print('\n----Conversor de metros para centimetros-----')

n1=float(input('\tValor em metros: ').replace(',','.'))
n2=n1*100
print('O valor em é : %.2f centimetros '%n2)