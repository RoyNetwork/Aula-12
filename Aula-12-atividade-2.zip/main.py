__author__ ='Alan (Roy)'

classe = {"Jimmy Hopkins": 9.0,
          "Bobby Kinball": 6.5,
          "Rod Stuward": 8.0,
          "Lewis Remington": 7.5,
          "Carl Johnson": 7.5}
notas = classe.values()
média = sum(notas)/5
print("A média desses senhores é ",média)